package com.example;

public class ExternalApi {
    public String getData() {
        
        return "Real Data";
    }
}
