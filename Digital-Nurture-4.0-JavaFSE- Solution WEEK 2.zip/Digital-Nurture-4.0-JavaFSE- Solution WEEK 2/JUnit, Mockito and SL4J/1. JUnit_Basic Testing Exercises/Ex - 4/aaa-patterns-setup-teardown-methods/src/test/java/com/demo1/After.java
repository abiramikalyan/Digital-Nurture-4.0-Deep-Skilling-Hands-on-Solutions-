package com.demo1;

public @interface After {

}
