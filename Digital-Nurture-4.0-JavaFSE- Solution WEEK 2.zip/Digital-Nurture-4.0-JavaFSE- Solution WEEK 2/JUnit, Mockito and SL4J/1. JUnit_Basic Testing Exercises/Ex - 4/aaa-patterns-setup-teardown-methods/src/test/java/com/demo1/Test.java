package com.demo1;

public @interface Test {

}
